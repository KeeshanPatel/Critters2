/*
Header
 */
package Assignment5;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Scanner;
import javafx.scene.Parent;
import java.util.Iterator;
import java.util.List;

import javafx.scene.image.*;
import javafx.stage.Stage;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.shape.*;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.scene.layout.*;

import javafx.scene.text.*;

import javafx.scene.control.*;

public class Main extends Application{

		public static final int TILE_SIZE = 50;
		public static final int WIDTH = 10;
		public static final int HEIGHT = 10;
		public static final int MENU_WIDTH = 2;

		// launch(args);
		static Scanner kb;	// scanner connected to keyboard input, or input file
		private static String inputFile;	// input file, used instead of keyboard input if specified
		static ByteArrayOutputStream testOutputString;	// if test specified, holds all console output
		private static String myPackage;	// package of Critter file.  Critter cannot be in default pkg.
		private static boolean DEBUG = false; // Use it or not, as you wish!
		static PrintStream old = System.out;	// if you want to restore output to console


		// Gets the package name.  The usage assumes that Critter and its subclasses are all in the same package.
		static {
			myPackage = Critter.class.getPackage().toString().split(" ")[1];
		}

		/**
		 * Main method.
		 * @param args args can be empty.  If not empty, provide two parameters -- the first is a file name,
		 * and the second is test (for test output, where all output to be directed to a String), or nothing.
		 */

		public void start(Stage primaryStage) throws Exception
		{
			Scene scene = new Scene(createContent());
			primaryStage.setTitle("source.CheckersApp");
			primaryStage.setScene(scene);

			primaryStage.show();
		}

		private Parent createContent()
		{
			Group tileGroup = new Group();
			Pane root = new Pane();
			root.setPrefSize(WIDTH * TILE_SIZE + MENU_WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
			root.getChildren().add(tileGroup);
			for(int x = 0; x < WIDTH; x++)
			{
				for(int y = 0; y < HEIGHT; y++)
				{
					Rectangle r = new Rectangle();
					r.setWidth(TILE_SIZE);
					r.setHeight(TILE_SIZE);

					r.relocate(x * TILE_SIZE, y * TILE_SIZE);
					r.setFill((x+y) % 2 == 0 ? Color.valueOf("#feb") : Color.valueOf("#582"));
					tileGroup.getChildren().add(r);
				}
			}
			Critter c = new Critter1();
			c.displayWorld(root, tileGroup, TILE_SIZE);
			return root;
		}
}


